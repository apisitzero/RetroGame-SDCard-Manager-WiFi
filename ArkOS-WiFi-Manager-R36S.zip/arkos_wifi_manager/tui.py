# -*- coding: utf-8 -*-
"""
TUI Display for ArkOS Wi-Fi Manager on R36S (640x480 Framebuffer Console)
Crafted for: เพจเล่าเรื่องเกม (Lao Reuang Game)
"""

import sys

# Standard ANSI Escape Codes
RESET   = "\033[0m"
BOLD    = "\033[1m"
GREEN   = "\033[1;32m"
CYAN    = "\033[1;36m"
YELLOW  = "\033[1;33m"
WHITE   = "\033[1;37m"
MAGENTA = "\033[1;35m"
GRAY    = "\033[90m"
BG_BLUE = "\033[44m"

# Stylized Thai ASCII Art Banner for "เล่าเรื่องเกม" (Font-safe on Linux consoles)
ASCII_THAI_BANNER = [
    "        |           .---.                                ",
    "       ---          | * |                                ",
    "  .---. .-----. .---. '--. .--' .-----. .----. .---. .-----. .-----. ",
    "  |   | |  _  | |   |   / /     |  _  | | .  | |   | |  _  | | | | | ",
    "  |   | | | | | |   |  / /_     | | | | | |  | |   | | | | | | | | | ",
    "  |   | | |_| | |   | |  _ \\    | |_| | | |  | |   | | |_| | | |_| | ",
    "  |   | |  _  | |   | | | | |   |  _  | | '-'| |   | |  _  | |  _  | ",
    "  '---' '-' '-' '---' '-' '-'   '-' '-' '--.-' '---' '-' '-' '-' '-' ",
    "                                           '-'                       "
]

def render_tui(ip: str, port: int, status: str = "ONLINE", pin: str = None) -> str:
    """Renders the terminal user interface tailored for R36S 640x480 screen."""
    lines = []
    lines.append("\033[2J\033[H")  # Clear screen and move cursor to (0,0)
    lines.append(f"{CYAN}===================================================================={RESET}")
    lines.append(f"{YELLOW}{BOLD}          * * *   P A G E :  L A O   R E U A N G   G A M E   * * *  {RESET}")
    lines.append(f"{CYAN}===================================================================={RESET}")
    
    # Print Thai ASCII art banner
    for b_line in ASCII_THAI_BANNER:
        lines.append(f"{MAGENTA}{b_line}{RESET}")
        
    lines.append(f"{WHITE}{BOLD}                [ L A O   R E U A N G   G A M E ]                   {RESET}")
    lines.append(f"{CYAN}--------------------------------------------------------------------{RESET}")
    lines.append(f" Status:  {GREEN}[ {status} ]{RESET}              {GRAY}Resolution: 640x480 (R36S / ArkOS){RESET}")
    lines.append(f" Address: {WHITE}{BOLD}http://{ip}:{port}{RESET}")
    if pin:
        lines.append(f" PIN:     {YELLOW}{BOLD}{pin}{RESET}  (Quick Access PIN)")
    lines.append(f"{CYAN}--------------------------------------------------------------------{RESET}")
    lines.append(f"{WHITE}{BOLD} Instructions:{RESET}")
    lines.append(f"  {CYAN}1.{RESET} Open a browser and enter the IP address shown above.")
    lines.append(f"  {CYAN}2.{RESET} Once connected, manage your games from the web page.")
    lines.append(f"  {CYAN}3.{RESET} To stop, close this terminal; the browser link will end too.")
    lines.append(f"{CYAN}===================================================================={RESET}")
    lines.append(f"{GRAY} Web Server is running on R36S. Press [Ctrl+C] or [B] button to exit{RESET}")
    return "\n".join(lines)

def print_tui(ip: str, port: int, status: str = "ONLINE", pin: str = None):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(render_tui(ip, port, status, pin), flush=True)

if __name__ == "__main__":
    print_tui("192.168.1.188", 8080, pin="5921")
