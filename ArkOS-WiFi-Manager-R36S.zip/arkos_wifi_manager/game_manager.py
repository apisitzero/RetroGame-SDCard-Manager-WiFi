# -*- coding: utf-8 -*-
"""
ArkOS On-Device Game Manager & Token Dictionary
Created for: เพจเล่าเรื่องเกม (Lao Reuang Game)
Author: AntiGravity
"""

import os
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path
import time
import mimetypes

SYSTEM_NAMES = {
    "gba": "Game Boy Advance",
    "gb": "Game Boy",
    "gbc": "Game Boy Color",
    "psx": "PlayStation 1",
    "sfc": "Super Famicom / SNES",
    "snes": "Super Nintendo",
    "nes": "Famicom / NES",
    "fc": "Famicom",
    "megadrive": "Sega Mega Drive / Genesis",
    "genesis": "Sega Genesis",
    "nds": "Nintendo DS",
    "psp": "PlayStation Portable",
    "n64": "Nintendo 64",
    "arcade": "Arcade Games",
    "mame": "MAME Arcade",
    "neogeo": "Neo Geo",
    "fbneo": "FinalBurn Neo",
    "pce": "PC Engine / TurboGrafx-16",
    "pcengine": "PC Engine",
    "wonderswan": "WonderSwan",
    "wsc": "WonderSwan Color",
    "gamegear": "Sega Game Gear",
    "mastersystem": "Sega Master System",
    "segacd": "Sega CD",
    "sega32x": "Sega 32X",
    "atarilynx": "Atari Lynx",
    "atari2600": "Atari 2600",
    "atari7800": "Atari 7800",
    "ports": "Ports Collection",
    "pico8": "PICO-8",
    "dreamcast": "Sega Dreamcast",
    "saturn": "Sega Saturn"
}

SYSTEM_ICONS = {
    "gba": "gamepad",
    "gb": "gamepad",
    "gbc": "gamepad",
    "psx": "compact-disc",
    "sfc": "gamepad",
    "snes": "gamepad",
    "nes": "gamepad",
    "fc": "gamepad",
    "megadrive": "gamepad",
    "nds": "mobile-screen",
    "psp": "gamepad",
    "n64": "cubes",
    "arcade": "vr-cardboard",
    "mame": "vr-cardboard",
    "neogeo": "vr-cardboard",
    "pce": "gamepad",
    "ports": "folder-open",
    "dreamcast": "compact-disc"
}

SAVE_EXTENSIONS = {'.srm', '.sav', '.state', '.state0', '.state1', '.state2', '.state3', '.state4', '.state5'}
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp'}
ROM_EXTENSIONS = {
    '.zip', '.7z', '.gba', '.gb', '.gbc', '.nes', '.sfc', '.smc', '.bin',
    '.cue', '.iso', '.chd', '.pbp', '.nds', '.n64', '.z64', '.v64',
    '.md', '.gen', '.pce', '.ws', '.wsc', '.gg', '.sms', '.cdi', '.gdi'
}

class ArkOSGameManager:
    def __init__(self, roms_root=None):
        self.roms_root = self._detect_roms_root(roms_root)
        self.token_registry = {}  # token -> full internal game dict
        self.cache = {}           # system_id -> {'xml_mtime': ..., 'games': [...]}
        print(f"[ArkOSGameManager] Detected ROMs root: {self.roms_root}")

    def _detect_roms_root(self, preferred_path=None):
        """Auto-detect ArkOS ROMs directory across SD1 and SD2."""
        candidates = []
        if preferred_path and os.path.exists(preferred_path):
            candidates.append(preferred_path)
            
        candidates.extend([
            "/roms2",                     # ArkOS SD Slot 2 (Dual SD setup)
            "/roms",                      # ArkOS SD Slot 1 (Single SD setup)
            "/mnt/roms",
            "/media/roms",
            "./roms",                     # Local development folder
            "../roms"
        ])
        
        for p in candidates:
            if os.path.exists(p) and os.path.isdir(p):
                try:
                    subdirs = [d for d in os.listdir(p) if os.path.isdir(os.path.join(p, d))]
                    if any(s in subdirs for s in ['gba', 'psx', 'nes', 'sfc', 'megadrive', 'ports']):
                        return os.path.abspath(p)
                except Exception:
                    pass
                    
        fallback = os.path.abspath("./roms")
        os.makedirs(fallback, exist_ok=True)
        return fallback

    def get_disk_info(self):
        """Get disk usage of the ROMs partition."""
        try:
            total, used, free = shutil.disk_usage(self.roms_root)
            total_gb = round(total / (1024 ** 3), 2)
            used_gb = round(used / (1024 ** 3), 2)
            free_gb = round(free / (1024 ** 3), 2)
            percent = round((used / total) * 100, 1) if total > 0 else 0
            return {
                "total_gb": total_gb,
                "used_gb": used_gb,
                "free_gb": free_gb,
                "percent": percent,
                "root_path": self.roms_root
            }
        except Exception as e:
            return {
                "total_gb": 0, "used_gb": 0, "free_gb": 0, "percent": 0,
                "root_path": self.roms_root, "error": str(e)
            }

    def list_systems(self):
        """List all available systems that have ROM directories or games."""
        systems = []
        if not os.path.exists(self.roms_root):
            return systems

        try:
            entries = sorted(os.listdir(self.roms_root))
        except Exception:
            return systems

        for name in entries:
            full_path = os.path.join(self.roms_root, name)
            if not os.path.isdir(full_path) or name.startswith('.'):
                continue
                
            display_name = SYSTEM_NAMES.get(name.lower(), name.upper())
            icon = SYSTEM_ICONS.get(name.lower(), "gamepad")
            
            systems.append({
                "id": name,
                "name": display_name,
                "path": full_path,
                "icon": icon
            })
            
        return systems

    def list_games(self, system_id, force_refresh=False):
        """
        List games with Token Dictionary mapping and RAM caching.
        Returns a list of tokenized game items for client consumption.
        """
        sys_path = os.path.join(self.roms_root, system_id)
        if not os.path.exists(sys_path) or not os.path.isdir(sys_path):
            return []

        gamelist_path = os.path.join(sys_path, "gamelist.xml")
        xml_mtime = os.path.getmtime(gamelist_path) if os.path.exists(gamelist_path) else 0

        # Check server-side memory cache
        if not force_refresh and system_id in self.cache:
            cached_entry = self.cache[system_id]
            if cached_entry['xml_mtime'] == xml_mtime:
                return cached_entry['games']

        # Parse XML if present
        xml_games = {}
        if os.path.exists(gamelist_path):
            xml_games = self._parse_gamelist(gamelist_path, sys_path)

        # Scan directory files
        games_list = []
        try:
            all_entries = sorted(os.listdir(sys_path), key=lambda s: s.lower())
        except Exception:
            all_entries = []

        seen_roms = set()
        idx = 0

        for entry in all_entries:
            if entry.startswith('.') or entry.lower() in ('gamelist.xml', 'images', 'boxart', 'downloaded_images'):
                continue

            entry_path = os.path.join(sys_path, entry)
            is_dir = os.path.isdir(entry_path)
            ext = os.path.splitext(entry)[1].lower()

            # Handle folder-based games (like in PS1 or Saturn)
            if is_dir:
                try:
                    cue_bin_files = [f for f in os.listdir(entry_path) if os.path.splitext(f)[1].lower() in ('.cue', '.m3u', '.chd', '.iso', '.pbp')]
                except Exception:
                    cue_bin_files = []
                if not cue_bin_files:
                    continue
                rom_filename = entry
                main_file = os.path.join(entry, cue_bin_files[0])
            else:
                if ext not in ROM_EXTENSIONS:
                    continue
                rom_filename = entry
                main_file = entry

            seen_roms.add(rom_filename.lower())
            idx += 1
            token = f"t_{system_id}_{idx}"

            # File size
            try:
                if is_dir:
                    size_bytes = sum(os.path.getsize(os.path.join(entry_path, f)) for f in os.listdir(entry_path) if os.path.isfile(os.path.join(entry_path, f)))
                else:
                    size_bytes = os.path.getsize(entry_path)
            except Exception:
                size_bytes = 0

            size_str = self._format_size(size_bytes)

            # Metadata from XML or filename
            meta = xml_games.get(rom_filename.lower()) or xml_games.get(main_file.lower()) or {}
            display_name = meta.get('name') or os.path.splitext(rom_filename)[0]
            desc = meta.get('desc', '')

            # Check cover
            cover_path = meta.get('image')
            has_cover = False
            full_cover_path = None
            if cover_path:
                norm_cover = cover_path.lstrip('./').lstrip('/')
                full_cover_path = os.path.join(sys_path, norm_cover)
                has_cover = os.path.exists(full_cover_path)
            
            if not has_cover:
                # Check default image conventions
                base_name = os.path.splitext(rom_filename)[0]
                for img_dir in ['images', 'boxart', 'downloaded_images']:
                    for img_ext in ['.png', '.jpg', '.jpeg', '.webp']:
                        for suffix in ['-image', '', '_cover']:
                            test_c = os.path.join(sys_path, img_dir, f"{base_name}{suffix}{img_ext}")
                            if os.path.exists(test_c):
                                has_cover = True
                                full_cover_path = test_c
                                cover_path = f"./{img_dir}/{os.path.basename(test_c)}"
                                break
                        if has_cover:
                            break
                    if has_cover:
                        break

            # Check save file
            has_save = False
            save_filename = None
            save_abs_path = None
            base_name = os.path.splitext(rom_filename)[0]
            for s_ext in SAVE_EXTENSIONS:
                s_path = os.path.join(sys_path, f"{base_name}{s_ext}")
                if os.path.exists(s_path):
                    has_save = True
                    save_filename = f"{base_name}{s_ext}"
                    save_abs_path = s_path
                    break

            # Build Full Internal Registry Object
            internal_obj = {
                "token": token,
                "system": system_id,
                "filename": rom_filename,
                "is_dir": is_dir,
                "main_file": main_file,
                "rom_abs_path": entry_path,
                "display_name": display_name,
                "desc": desc,
                "size_bytes": size_bytes,
                "size_str": size_str,
                "has_cover": has_cover,
                "cover_rel_path": cover_path,
                "cover_abs_path": full_cover_path,
                "has_save": has_save,
                "save_filename": save_filename,
                "save_abs_path": save_abs_path
            }

            self.token_registry[token] = internal_obj

            # Client-facing payload (tokenized)
            client_item = {
                "token": token,
                "system": system_id,
                "filename": rom_filename,
                "display_name": display_name,
                "size_str": size_str,
                "has_cover": has_cover,
                "has_save": has_save,
                "save_filename": save_filename,
                "is_dir": is_dir
            }
            games_list.append(client_item)

        # Store in Server-Side Cache
        self.cache[system_id] = {
            "xml_mtime": xml_mtime,
            "games": games_list
        }

        return games_list

    def _parse_gamelist(self, gamelist_path, sys_path):
        """Parse gamelist.xml efficiently using ElementTree."""
        result = {}
        try:
            tree = ET.parse(gamelist_path)
            root = tree.getroot()
            for game_elem in root.findall('game'):
                path_elem = game_elem.find('path')
                if path_elem is None or not path_elem.text:
                    continue
                rel_path = path_elem.text.strip().lstrip('./').lstrip('/')
                name_elem = game_elem.find('name')
                desc_elem = game_elem.find('desc')
                img_elem = game_elem.find('image')

                name = name_elem.text.strip() if (name_elem is not None and name_elem.text) else None
                desc = desc_elem.text.strip() if (desc_elem is not None and desc_elem.text) else ""
                image = img_elem.text.strip() if (img_elem is not None and img_elem.text) else None

                key = os.path.basename(rel_path).lower()
                result[key] = {
                    "name": name,
                    "desc": desc,
                    "image": image,
                    "path": rel_path
                }
                result[rel_path.lower()] = result[key]
        except Exception as e:
            print(f"[ArkOSGameManager] XML parse error {gamelist_path}: {e}")
        return result

    def get_game_by_token(self, token):
        """Retrieve full game metadata via token."""
        return self.token_registry.get(token)

    def rename_game(self, token, new_display_name):
        """Update display name in gamelist.xml."""
        game = self.get_game_by_token(token)
        if not game:
            return {"success": False, "error": "Game token not found"}

        system_id = game["system"]
        sys_path = os.path.join(self.roms_root, system_id)
        gamelist_path = os.path.join(sys_path, "gamelist.xml")

        try:
            if os.path.exists(gamelist_path):
                tree = ET.parse(gamelist_path)
                root = tree.getroot()
            else:
                root = ET.Element("gameList")
                tree = ET.ElementTree(root)

            target_path_1 = f"./{game['filename']}".lower()
            target_path_2 = f"./{game['main_file']}".lower()
            found_elem = None

            for g_elem in root.findall('game'):
                p = g_elem.find('path')
                if p is not None and p.text:
                    clean_p = p.text.strip().lower()
                    if clean_p in (target_path_1, target_path_2, game['filename'].lower()):
                        found_elem = g_elem
                        break

            if found_elem is None:
                found_elem = ET.SubElement(root, 'game')
                p_elem = ET.SubElement(found_elem, 'path')
                p_elem.text = f"./{game['filename']}"

            n_elem = found_elem.find('name')
            if n_elem is None:
                n_elem = ET.SubElement(found_elem, 'name')
            n_elem.text = new_display_name

            tree.write(gamelist_path, encoding='utf-8', xml_declaration=True)

            if system_id in self.cache:
                del self.cache[system_id]

            game["display_name"] = new_display_name
            return {"success": True, "display_name": new_display_name}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def apply_cover(self, token, image_bytes, filename_ext=".png"):
        """Save cover image directly to system/images and update gamelist.xml."""
        game = self.get_game_by_token(token)
        if not game:
            return {"success": False, "error": "Game token not found"}

        system_id = game["system"]
        sys_path = os.path.join(self.roms_root, system_id)
        images_dir = os.path.join(sys_path, "images")
        os.makedirs(images_dir, exist_ok=True)

        base_name = os.path.splitext(game["filename"])[0]
        cover_filename = f"{base_name}-image{filename_ext}"
        cover_abs_path = os.path.join(images_dir, cover_filename)
        rel_cover_path = f"./images/{cover_filename}"

        try:
            with open(cover_abs_path, 'wb') as f:
                f.write(image_bytes)

            # Update XML
            gamelist_path = os.path.join(sys_path, "gamelist.xml")
            if os.path.exists(gamelist_path):
                tree = ET.parse(gamelist_path)
                root = tree.getroot()
            else:
                root = ET.Element("gameList")
                tree = ET.ElementTree(root)

            target_path_1 = f"./{game['filename']}".lower()
            found_elem = None
            for g_elem in root.findall('game'):
                p = g_elem.find('path')
                if p is not None and p.text and p.text.strip().lower() == target_path_1:
                    found_elem = g_elem
                    break

            if found_elem is None:
                found_elem = ET.SubElement(root, 'game')
                p_elem = ET.SubElement(found_elem, 'path')
                p_elem.text = f"./{game['filename']}"
                n_elem = ET.SubElement(found_elem, 'name')
                n_elem.text = game["display_name"]

            img_elem = found_elem.find('image')
            if img_elem is None:
                img_elem = ET.SubElement(found_elem, 'image')
            img_elem.text = rel_cover_path

            tree.write(gamelist_path, encoding='utf-8', xml_declaration=True)

            if system_id in self.cache:
                del self.cache[system_id]

            game["has_cover"] = True
            game["cover_abs_path"] = cover_abs_path
            game["cover_rel_path"] = rel_cover_path

            return {"success": True, "cover_path": rel_cover_path}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def delete_game(self, token):
        """Delete game ROM, cover image, and save file safely via token."""
        game = self.get_game_by_token(token)
        if not game:
            return {"success": False, "error": "Game token not found"}

        system_id = game["system"]
        try:
            if os.path.exists(game["rom_abs_path"]):
                if game["is_dir"]:
                    shutil.rmtree(game["rom_abs_path"])
                else:
                    os.remove(game["rom_abs_path"])

            if game.get("cover_abs_path") and os.path.exists(game["cover_abs_path"]):
                try:
                    os.remove(game["cover_abs_path"])
                except Exception:
                    pass

            sys_path = os.path.join(self.roms_root, system_id)
            gamelist_path = os.path.join(sys_path, "gamelist.xml")
            if os.path.exists(gamelist_path):
                tree = ET.parse(gamelist_path)
                root = tree.getroot()
                target_path = f"./{game['filename']}".lower()
                for g_elem in root.findall('game'):
                    p = g_elem.find('path')
                    if p is not None and p.text and p.text.strip().lower() == target_path:
                        root.remove(g_elem)
                        break
                tree.write(gamelist_path, encoding='utf-8', xml_declaration=True)

            if system_id in self.cache:
                del self.cache[system_id]
            if token in self.token_registry:
                del self.token_registry[token]

            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def save_uploaded_rom(self, system_id, filename, file_bytes, display_name=None):
        """Save newly uploaded ROM file into system directory and update gamelist.xml."""
        sys_path = os.path.join(self.roms_root, system_id)
        if not os.path.exists(sys_path):
            os.makedirs(sys_path, exist_ok=True)

        target_file_path = os.path.join(sys_path, filename)
        try:
            with open(target_file_path, 'wb') as f:
                f.write(file_bytes)

            # Update gamelist.xml if display_name is specified
            clean_display = display_name if (display_name and display_name.strip()) else os.path.splitext(filename)[0]
            gamelist_path = os.path.join(sys_path, "gamelist.xml")
            if os.path.exists(gamelist_path):
                tree = ET.parse(gamelist_path)
                root = tree.getroot()
            else:
                root = ET.Element("gameList")
                tree = ET.ElementTree(root)

            # Check if game already in XML
            target_path = f"./{filename}".lower()
            found = False
            for g_elem in root.findall('game'):
                p = g_elem.find('path')
                if p is not None and p.text and p.text.strip().lower() == target_path:
                    found = True
                    n = g_elem.find('name')
                    if n is not None:
                        n.text = clean_display
                    break

            if not found:
                g_elem = ET.SubElement(root, 'game')
                p = ET.SubElement(g_elem, 'path')
                p.text = f"./{filename}"
                n = ET.SubElement(g_elem, 'name')
                n.text = clean_display

            tree.write(gamelist_path, encoding='utf-8', xml_declaration=True)

            # Invalidate cache
            if system_id in self.cache:
                del self.cache[system_id]

            return {"success": True, "filename": filename, "display_name": clean_display}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _format_size(self, size_bytes):
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            return f"{round(size_bytes / 1024, 1)} KB"
        elif size_bytes < 1024 * 1024 * 1024:
            return f"{round(size_bytes / (1024 * 1024), 1)} MB"
        else:
            return f"{round(size_bytes / (1024 * 1024 * 1024), 2)} GB"
